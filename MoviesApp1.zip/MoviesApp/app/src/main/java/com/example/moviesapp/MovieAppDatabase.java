package com.example.moviesapp;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {MovieData.class}, version = 3)
public abstract class MovieAppDatabase extends RoomDatabase {
    public abstract MovieDAO movieDAO();

    public MovieDAO MovieDao() {
    }
}
