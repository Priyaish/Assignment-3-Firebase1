package com.example.moviesapp;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "movies")
public class MovieData {
    @PrimaryKey(autoGenerate = true)
    public int movieID;

    public String title;
    public String studio;
    public float rating;
    // public String thumbnailPath;

    public MovieData(String title, String studio, float rating) {
        this.title = title;
        this.studio = studio;
        this.rating = rating;
        // this.thumbnailPath = thumbnailPath;
    }

    public int getId() {
        return movieID;
    }

    public String gettitle() {
        return title;
    }

    public String getStudio() {
        return studio;
    }

    public float getRating() {
        return rating;
    }

    public void settitle(String title) {
        this.title = title;
    }

    public void setStudio(String studio) {
        this.studio = studio;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public int getTitle() {
    }
}
