package com.example.moviesapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Arrays;

public class AddEditMovie extends AppCompatActivity {
    private EditText editTextTitle, editTextStudio, editTextRating;
    private Button btnSave;
    private movies db;
    private int movieId = -1;
    private boolean isEditing = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_edit_screen);

        editTextTitle = findViewById(R.id.editTextMovieTitle);
        editTextStudio = findViewById(R.id.editTextMovieStudio);
        editTextRating = findViewById(R.id.editTextMovieRating);
        btnSave = findViewById(R.id.btnsave);

        db = movieId; // Initialize Room database

        // Check if it's edit mode
        movieId = getIntent().getIntExtra("MOVIE_ID", -1);
        if (movieId != -1) {
            isEditing = true;
            loadMovieData(movieId);
        }

        btnSave.setOnClickListener(v -> saveMovie());
    }

    private void loadMovieData(int movieId) {
        new Thread(() -> {
            MovieData movie = db.MovieDAO().getMovieById(movieId);
            if (movie != null) {
                runOnUiThread(() -> {
                    editTextTitle.setText(movie.getTitle());
                    editTextStudio.setText(movie.getStudio());
                    editTextRating.setText(String.valueOf(movie.getRating()));
                });
            }
        }).start();
    }

    private void saveMovie() {
        String title = editTextTitle.getText().toString();
        String studio = editTextStudio.getText().toString();
        float rating;
        try {
            rating = Float.parseFloat(editTextRating.getText().toString());
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid rating format", Toast.LENGTH_SHORT).show();
            return;
        }

        new Thread(() -> {
            MovieData movie = new MovieData(title, studio, rating);
            if (isEditing) {
                movie.setId(movieId);
                db.movieDao().update(movie);
            } else {
                db.movieDao().insert(movie);
            }
            runOnUiThread(() -> {
                Toast.makeText(this, isEditing ? "Movie updated" : "Movie added", Toast.LENGTH_SHORT).show();
                finish(); // Exit Activity
            });
        }).start();
    }

    private class movies {
    }
}
