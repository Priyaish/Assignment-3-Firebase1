package com.example.moviesapp;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class JsonUtilityHelper {

    public static List<MovieData> loadMoviesFromAsset(Context context, String fileName) {
        try {
            InputStream is = context.getAssets().open(fileName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            String json = new String(buffer, "UTF-8");

            JSONObject jsonObject = new JSONObject(json);
            JSONArray jsonArray = jsonObject.getJSONArray("Sheet1");

            List<MovieData> movieList = new ArrayList<>();
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj = jsonArray.getJSONObject(i);
                MovieData movie = new MovieData(
                        obj.getString("title"),
                        obj.getString("studio"),
                        (float) obj.getDouble("criticsRating")
                        //obj.getString("thumbnailPath")
                );
                movieList.add(movie);
            }

            return movieList;
        } catch (IOException | JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static class MovieAdapter {
    }
}

