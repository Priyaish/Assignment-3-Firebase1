package com.example.moviesapp;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

    public class MovieListActivity extends ComponentActivity {

        private ListView listView;

        private boolean isActivityLoaded = false;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.movie_listrc);

            listView = findViewById(R.id.listViewMovies);

            Button buttonAdd = findViewById(R.id.buttonAdd);
            buttonAdd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(MovieListActivity.this, AddEditMovie.class);
                    intent.putExtra("mode", "add");
                    startActivity(intent);
                }
            });
        }

        @Override
        protected void onResume() {
            super.onResume();
            DatabaseHelper databaseHelper = new DatabaseHelper(this);
            List<Movie> movieList = databaseHelper.getAllMovies();
            MovieAdapter adapter = new MovieAdapter(this, movieList);
            listView.setAdapter(adapter);
        }

    }
}
