package com.example.moviesapp;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


import java.util.ArrayList;


import androidx.annotation.NonNull;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "AssignDB";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_MOVIES = "movies";
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PASSWORD = "password";
    private static final String CREATE_USERS_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_USERS + "(" +
            COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            COLUMN_EMAIL + " TEXT," +
            COLUMN_PASSWORD + " TEXT" + ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        createMoviesTable(db);
        db.execSQL(CREATE_USERS_TABLE);
        insertSampleData(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MOVIES);
        onCreate(db);
    }

    public SQLiteDatabase openDatabase() {
        return this.getWritableDatabase();
    }

    private boolean isTableExists(SQLiteDatabase db, String tableName) {
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM sqlite_master WHERE type = ? AND name = ?",
                new String[] {"table", tableName});
        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    int count = cursor.getInt(0);
                    return count > 0;
                }
            } finally {
                cursor.close();
            }
        }
        return false;
    }


    public List<Movie> getAllMovies() {
        List<Movie> movieList = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        if (!isTableExists(db, TABLE_MOVIES)) {
            createMoviesTable(db);
            insertSampleData(db);
        }

        if (db != null && db.isOpen()) {
            Cursor cursor = db.rawQuery("SELECT * FROM 'movies' LIMIT 0,30", null);

            if (cursor != null) {
                try {
                    while (cursor.moveToNext()) {
                        Movie movie =   new Movie();
                        int idIndex = cursor.getColumnIndex("id");
                        if (idIndex != -1) {
                            movie.setmovieID(cursor.getInt(idIndex));
                        }
                        int titleIndex = cursor.getColumnIndex("title");
                        if (titleIndex != -1) {
                            movie.setTitle(cursor.getString(titleIndex));
                        }

                        int studioIndex = cursor.getColumnIndex("studio");
                        if (studioIndex != -1) {
                            movie.setStudio(cursor.getString(studioIndex));
                        }

                        int thumbnailIndex = cursor.getColumnIndex("thumbnail");
                        if (thumbnailIndex != -1) {
                            movie.setThumbnailUrl(cursor.getString(thumbnailIndex));
                        }

                        int ratingIndex = cursor.getColumnIndex("rating");
                        if (ratingIndex != -1) {
                            movie.setRating(cursor.getDouble(ratingIndex));
                        }
                        movieList.add(movie);
                    }
                } finally {
                    cursor.close();
                }
            }}

        // Close the database connection
        db.close();

        return movieList;
    }

    private void createMoviesTable(@NonNull SQLiteDatabase db) {
        db.execSQL("CREATE TABLE movies ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "title TEXT,"
                + "studio TEXT,"
                + "thumbnail TEXT,"
                + "rating REAL)");
    }

    private void insertSampleData(SQLiteDatabase db) {
        ContentValues values = new ContentValues();
        values.put("title", "Star Wars: Episode V - The Empire Strikes Back");
        values.put("studio", "Twentieth Century Fox");
        values.put("thumbnail", "https://images.squarespace-cdn.com/content/v1/517e691fe4b08478234f6532/1402388442150-T9IUFL2WFXLH2HL9XUD3/20th_Century_Fox_Logo_Turbo_2013.png");
        values.put("rating", 8.7);
        db.insert("movies", null, values);

        ContentValues values2 = new ContentValues();
        values2.put("title", "The Matrix");
        values2.put("studio", "Warner Bros. Pictures");
        values2.put("thumbnail", "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Warner_Bros._Pictures_2023_%28Alt%29.svg/1200px-Warner_Bros._Pictures_2023_%28Alt%29.svg.png");
        values2.put("rating", 8.7);
        db.insert("movies", null, values2);

        ContentValues values3 = new ContentValues();
        values3.put("title", "Star Wars: Episode IV - A New Hope");
        values3.put("studio", "Twentieth Century Fox");
        values3.put("thumbnail", "https://images.squarespace-cdn.com/content/v1/517e691fe4b08478234f6532/1402388442150-T9IUFL2WFXLH2HL9XUD3/20th_Century_Fox_Logo_Turbo_2013.png");
        values3.put("rating", 8.6);
        db.insert("movies", null, values3);

        ContentValues values4 = new ContentValues();
        values4.put("title", "Back to the Future");
        values4.put("studio", "Universal Pictures");
        values4.put("thumbnail", "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/04b0e30e-c394-4e4f-b4bb-b0bb99c50e22/dgmf27h-4b9854bc-102a-4516-96ba-e3fa6591a74b.png/v1/fill/w_1206,h_663/universal_pictures_logo_combination__1997___2012__by_vincerabina_dgmf27h-pre.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NzA0IiwicGF0aCI6IlwvZlwvMDRiMGUzMGUtYzM5NC00ZTRmLWI0YmItYjBiYjk5YzUwZTIyXC9kZ21mMjdoLTRiOTg1NGJjLTEwMmEtNDUxNi05NmJhLWUzZmE2NTkxYTc0Yi5wbmciLCJ3aWR0aCI6Ijw9MTI4MCJ9XV0sImF1ZCI6WyJ1cm46c2VydmljZTppbWFnZS5vcGVyYXRpb25zIl19.-rplGnOCxARJ7qu2Mtl8I2FE8DUa4oHvpnr1v5CV7zM");
        values4.put("rating", 8.6);
        db.insert("movies", null, values4);

        ContentValues values5 = new ContentValues();
        values5.put("title", "Alien");
        values5.put("studio", "Twentieth Century Fox");
        values5.put("thumbnail", "https://images.squarespace-cdn.com/content/v1/517e691fe4b08478234f6532/1402388442150-T9IUFL2WFXLH2HL9XUD3/20th_Century_Fox_Logo_Turbo_2013.png");
        values5.put("rating", 8.5);
        db.insert("movies", null, values5);

        ContentValues values6 = new ContentValues();
        values6.put("title", "Raiders of th Lost Ark");
        values6.put("studio", "Paramount Pictures");
        values6.put("thumbnail", "https://i.ytimg.com/vi/wnfDBLIprkQ/mqdefault.jpg");
        values6.put("rating", 8.4);
        db.insert("movies", null, values6);

        ContentValues values7 = new ContentValues();
        values7.put("title", "Blade Runner");
        values7.put("studio", "Warner Bros. Pictures");
        values7.put("thumbnail", "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Warner_Bros._Pictures_2023_%28Alt%29.svg/1200px-Warner_Bros._Pictures_2023_%28Alt%29.svg.png");
        values7.put("rating", 8.1);
        db.insert("movies", null, values7);

        ContentValues values8 = new ContentValues();
        values8.put("title", "The Terminator");
        values8.put("studio", "Orion Pictures");
        values8.put("thumbnail", "https://i.ytimg.com/vi/bs8RErQHrwU/maxresdefault.jpg");
        values8.put("rating", 8.1);
        db.insert("movies", null, values8);

        ContentValues values9 = new ContentValues();
        values9.put("title", "Star Trek II: The Wrath of Khan");
        values9.put("studio", "Paramount Pictures");
        values9.put("thumbnail", "https://i.ytimg.com/vi/wnfDBLIprkQ/mqdefault.jpg");
        values9.put("rating", 7.7);
        db.insert("movies", null, values9);

        ContentValues values10 = new ContentValues();
        values10.put("title", "The Princess Bride");
        values10.put("studio", "Twentieth Century Fox");
        values10.put("thumbnail", "https://images.squarespace-cdn.com/content/v1/517e691fe4b08478234f6532/1402388442150-T9IUFL2WFXLH2HL9XUD3/20th_Century_Fox_Logo_Turbo_2013.png");
        values10.put("rating", 8);
        db.insert("movies", null, values10);
    }

    public long addMovie(Movie movie) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("title", movie.getTitle());
        values.put("studio", movie.getStudio());
        values.put("rating", movie.getRating());
        long result = db.insert("movies", null, values);
        db.close();
        return result;

    }

    public boolean deleteMovie(int movieId) {
        SQLiteDatabase db = this.getWritableDatabase();
        boolean isDeleted = false;

        try {
            String selection = "id=?";
            String[] selectionArgs = { String.valueOf(movieId) };

            int deletedRows = db.delete("movies", selection, selectionArgs);

            // Check if the deletion was successful
            if (deletedRows > 0) {
                isDeleted = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            db.close();
        }

        return isDeleted;
    }

    public long updateMovie(int movieId, Movie movie) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("title", movie.getTitle());
        values.put("studio", movie.getStudio());
        values.put("rating", movie.getRating());
        long result = db.update("movies", values, "id=?", new String[]{String.valueOf(movieId)});
        db.close();
        return result;
    }

    public long addUser(String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result;
    }
    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " +
                COLUMN_EMAIL + " = ? AND " + COLUMN_PASSWORD + " = ?", new String[]{email, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

}
