package com.example.moviesapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.EmailAuthCredential;
import com.google.firebase.auth.FirebaseAuth;

public class signup_activity extends AppCompatActivity {

        private EditText editTextEmail;
        private EditText editTextPassword;
        private lateinit var auth: firebaseAuth;

        auth = firebase.auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup_activity);

        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
    }
        public override fun onStart() {
            super.onStart()
            val currentUser = auth.currentUser
            updateUI(currentUser)
    public void onClickSignUp(View Object view;
            view) {
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            Toast.makeText(getApplicationContext(), "Please enter email and password", Toast.LENGTH_SHORT).show();
            return;
        }
        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        databaseHelper.addUser(email, password);
        startActivity(new Intent(signup_activity.this, MovieListActivity.class));
        Toast.makeText(getApplicationContext(), "User created successfully!", Toast.LENGTH_SHORT).show();
        finish();
    }

    public void onClickLogin(View view) {
        startActivity(new Intent(signup_activity.this, login_activity.class));
    }
}

