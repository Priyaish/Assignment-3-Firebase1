package com.example.moviesapp;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface MovieDAO {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertMovies(List<MovieData> movies);

    @Query("SELECT * FROM movies")
    List<MovieData> getAllMovies();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(MovieData movie);


    @Update
    void update(MovieData movie);

    @Delete
    void delete(MovieData movie);

    @Query("SELECT * FROM movies WHERE movieID = :movieId")
    MovieData getMovieById(int movieId);
}




