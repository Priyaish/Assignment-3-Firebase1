package com.example.moviesapp;

import android.os.Parcel;
import android.os.Parcelable;

public class Movie implements Parcelable {
    private int movieID;
    private String title;
    private String studio;
    private double rating;

    private String thumbnailUrl;

    // Constructor
    public Movie() {
        // Default constructor
    }
    public Movie(String title, String studio, String thumbnailUrl, double rating) {
        this.title = title;
        this.studio = studio;
        this.thumbnailUrl = thumbnailUrl;
        this.rating = rating;
    }

    // Getters and Setters
    public String getTitle() {
        return title;
    }
    public int getMovieID(){
        return movieID;
    }

    public void setMovieID(int movieID){
        this.movieID = movieID;
    }
    public void setTitle(String title) {
        this.title = title;
    }

    public String getStudio() {
        return studio;
    }
    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setStudio(String studio) {
        this.studio = studio;
    }
    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    // Parcelable implementation
    protected Movie(Parcel in) {
        title = in.readString();
        studio = in.readString();
        rating = in.readDouble();
        movieID = in.readInt();
    }

    public static final Creator<Movie> CREATOR = new Creator<Movie>() {
        @Override
        public Movie createFromParcel(Parcel in) {
            return new Movie(in);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeString(studio);
        dest.writeDouble(rating);
        dest.writeInt(movieID);
    }
}
